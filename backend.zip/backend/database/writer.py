from backend.database.db import get_connection

def save_packet(packet_info):
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO packets (
                timestamp, src_ip, dst_ip, protocol,
                src_port, dst_port, packet_size
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            packet_info.get("timestamp"),
            packet_info.get("src_ip"),
            packet_info.get("dst_ip"),
            packet_info.get("protocol"),
            packet_info.get("src_port"),
            packet_info.get("dst_port"),
            packet_info.get("packet_size"),
        ))

def save_packets_batch(packet_infos):
    if not packet_infos:
        return 0

    with get_connection() as conn:
        conn.executemany("""
            INSERT INTO packets (
                timestamp, src_ip, dst_ip, protocol,
                src_port, dst_port, packet_size
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, [
            (
                p.get("timestamp"), p.get("src_ip"),
                p.get("dst_ip"), p.get("protocol"),
                p.get("src_port"), p.get("dst_port"),
                p.get("packet_size"),
            )
            for p in packet_infos
        ])

    return len(packet_infos)
