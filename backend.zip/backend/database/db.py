import sqlite3
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "data" / "network_traffic.db"

def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn

def initialize_database():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS packets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                src_ip TEXT,
                dst_ip TEXT,
                protocol TEXT,
                src_port INTEGER,
                dst_port INTEGER,
                packet_size INTEGER
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_packets_timestamp
            ON packets(timestamp)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_packets_protocol
            ON packets(protocol)
        """)

def get_packet_count():
    with get_connection() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM packets"
        ).fetchone()[0]
