
import threading
from scapy.all import sniff
from backend.analyzer.decoder import decode_packet
from backend.database.writer import save_packet
from backend.analyzer.alert_service import inspect_packet


class CaptureManager:
    def __init__(self, interface="Wi-Fi"):
        self.interface = interface
        self._thread = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._running = False
        self._captured = 0
        self._errors = []

    def _on_packet(self, packet):
        try:
            packet_data = decode_packet(packet)
            inspect_packet(packet_data)
            save_packet(packet_data)

            with self._lock:
                self._captured += 1

        except Exception as exc:
            with self._lock:
                self._errors.append(str(exc))
                self._errors = self._errors[-10:]

    def _worker(self):
        try:
            while not self._stop_event.is_set():
                sniff(
                    iface=self.interface,
                    prn=self._on_packet,
                    store=False,
                    timeout=1,
                )
        except Exception as exc:
            with self._lock:
                self._errors.append(str(exc))
                self._errors = self._errors[-10:]
        finally:
            with self._lock:
                self._running = False

    def start(self):
        with self._lock:
            if self._running:
                return {
                    "started": False,
                    "message": "Capture is already running",
                }

            self._stop_event.clear()
            self._captured = 0
            self._running = True
            self._thread = threading.Thread(
                target=self._worker,
                daemon=True,
            )
            self._thread.start()

        return {"started": True, "interface": self.interface}

    def stop(self):
        self._stop_event.set()
        thread = self._thread

        if thread and thread.is_alive():
            thread.join(timeout=3)

        with self._lock:
            return {
                "running": self._running,
                "captured_since_start": self._captured,
            }

    def status(self):
        with self._lock:
            return {
                "running": self._running,
                "interface": self.interface,
                "captured_since_start": self._captured,
                "errors": list(self._errors),
            }


capture_manager = CaptureManager()
