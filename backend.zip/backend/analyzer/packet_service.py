from backend.database.db import get_connection

def get_recent_packets(limit=100, protocol=None):
    limit = max(1, min(int(limit), 1000))

    query = """
        SELECT id, timestamp, src_ip, dst_ip, protocol,
               src_port, dst_port, packet_size
        FROM packets
    """
    params = []

    if protocol:
        query += " WHERE protocol = ?"
        params.append(protocol.upper())

    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    with get_connection() as conn:
        rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

def get_protocol_summary():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT protocol,
                   COUNT(*) AS packet_count,
                   SUM(packet_size) AS total_bytes
            FROM packets
            GROUP BY protocol
            ORDER BY packet_count DESC
        """).fetchall()

    return [dict(row) for row in rows]
