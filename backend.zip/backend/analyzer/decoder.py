from datetime import datetime
from scapy.all import IP, TCP, UDP, ICMP, IPv6

def decode_packet(packet):
    info = {
        "timestamp": datetime.fromtimestamp(
            float(packet.time)
        ).isoformat(timespec="milliseconds"),
        "src_ip": None,
        "dst_ip": None,
        "protocol": "Other",
        "src_port": None,
        "dst_port": None,
        "packet_size": len(packet),
    }

    if IP in packet:
        info["src_ip"] = packet[IP].src
        info["dst_ip"] = packet[IP].dst
    elif IPv6 in packet:
        info["src_ip"] = packet[IPv6].src
        info["dst_ip"] = packet[IPv6].dst

    if TCP in packet:
        info["protocol"] = "TCP"
        info["src_port"] = int(packet[TCP].sport)
        info["dst_port"] = int(packet[TCP].dport)
    elif UDP in packet:
        info["protocol"] = "UDP"
        info["src_port"] = int(packet[UDP].sport)
        info["dst_port"] = int(packet[UDP].dport)
    elif ICMP in packet:
        info["protocol"] = "ICMP"
    elif IPv6 in packet:
        info["protocol"] = "IPv6"

    return info
