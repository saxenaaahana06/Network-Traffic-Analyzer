
from collections import defaultdict, deque
from datetime import datetime, timezone
import threading
import time

WINDOW_SECONDS = 30
PORT_THRESHOLD = 15
ALERT_COOLDOWN = 60
MAX_ALERTS = 100

_lock = threading.Lock()
_recent_ports = defaultdict(deque)
_last_alert = {}
_alerts = []
_next_id = 1


def inspect_packet(packet_data):
    global _next_id

    src_ip = packet_data.get("src_ip")
    dst_port = packet_data.get("dst_port")
    protocol = str(packet_data.get("protocol") or "").upper()

    if not src_ip or dst_port is None or protocol not in {"TCP", "UDP"}:
        return

    try:
        dst_port = int(dst_port)
        if not 0 <= dst_port <= 65535:
            return
    except (TypeError, ValueError):
        return

    now = time.monotonic()

    with _lock:
        history = _recent_ports[src_ip]
        history.append((now, dst_port))

        while history and now - history[0][0] > WINDOW_SECONDS:
            history.popleft()

        distinct_ports = len({port for _, port in history})

        if distinct_ports < PORT_THRESHOLD:
            return

        if now - _last_alert.get(src_ip, 0) < ALERT_COOLDOWN:
            return

        _last_alert[src_ip] = now

        alert = {
            "id": _next_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "severity": "medium",
            "type": "Possible Port Scan",
            "src_ip": src_ip,
            "message": (
                f"{src_ip} contacted {distinct_ports} different "
                f"destination ports within {WINDOW_SECONDS} seconds."
            ),
            "distinct_ports": distinct_ports,
        }

        _next_id += 1
        _alerts.insert(0, alert)
        del _alerts[MAX_ALERTS:]


def get_alerts():
    with _lock:
        return list(_alerts)
