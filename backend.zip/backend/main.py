from contextlib import asynccontextmanager
from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from backend.database.db import initialize_database, get_packet_count
from backend.analyzer.packet_service import (
    get_recent_packets,
    get_protocol_summary,
)
from backend.capture.manager import capture_manager
from backend.analyzer.alert_service import get_alerts

@asynccontextmanager
async def lifespan(app: FastAPI):
    initialize_database()
    yield
    capture_manager.stop()

app = FastAPI(
    title="Network Traffic Analyzer API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "Network Traffic Analyzer API", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "healthy"}

@app.get("/api/stats")
def stats():
    return {
        "total_packets": get_packet_count(),
        "protocols": get_protocol_summary(),
    }

@app.get("/api/packets")
def packets(
    limit: int = Query(default=100, ge=1, le=1000),
    protocol: str | None = None,
):
    return get_recent_packets(limit=limit, protocol=protocol)

@app.get("/api/capture/status")
def capture_status():
    return capture_manager.status()

@app.post("/api/capture/start")
def capture_start():
    result = capture_manager.start()
    if not result.get("started"):
        raise HTTPException(status_code=409, detail=result["message"])
    return result

@app.post("/api/capture/stop")
def capture_stop():
    return capture_manager.stop()
@app.get("/api/alerts")
def alerts():
    return get_alerts()